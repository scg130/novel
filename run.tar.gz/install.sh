#!/bin/bash
yum install -y vim bash-completion lrzsz conntrack ipvsadm ipset jq sysstat curl

systemctl disable firewalld && systemctl stop firewalld

sed -i "s/SELINUX=enforcing/SELINUX=disabled/g" /etc/selinux/config

swapoff -a
sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab

cat > /etc/sysconfig/modules/ipvs.modules << EOF
#!/bin/bash
modprobe -- ip_vs
modprobe -- ip_vs_rr
modprobe -- ip_vs_wrr
modprobe -- ip_vs_sh
modprobe -- nf_conntrack_ipv4
modprobe -- br_netfilter
EOF
bash /etc/sysconfig/modules/ipvs.modules

cat > /etc/sysctl.d/k8s.conf << EOF
net.bridge.bridge-nf-call-iptables=1
net.bridge.bridge-nf-call-ip6tables=1
net.ipv4.ip_forward=1
net.ipv4.tcp_tw_recycle=0
vm.swappiness=0
vm.overcommit_memory=1
vm.panic_on_oom=0
fs.inotify.max_user_watches=89100
fs.file-max=52706963
fs.nr_open=52706963
net.ipv6.conf.all.disable_ipv6=1
net.netfilter.nf_conntrack_max=2310720
EOF
sysctl -p /etc/sysctl.d/k8s.conf

yum -y remove docker \
           docker-client \
           docker-client-latest \
           docker-common \
           docker-latest \
           docker-latest-logrotate \
           docker-logrotate \
           docker-selinux \
           docker-engine-selinux \
           docker-engine

yum -y install yum-utils device-mapper-persistent-data lvm2
yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
sed -i 's+download.docker.com+mirrors.aliyun.com/docker-ce+' /etc/yum.repos.d/docker-ce.repo
yum makecache fast
yum list docker-ce --showduplicates | sort -r   #列出docker-ce的版本

yum -y install docker-ce-20.10.8
mkdir /etc/docker
cat > /etc/docker/daemon.json << EOF
{
    "registry-mirrors": ["https://9xx4btvq.mirror.aliyuncs.com"],
    "exec-opts": ["native.cgroupdriver=systemd"],
    "log-driver": "json-file",
    "log-opts": {
    "max-size": "100m"
},
    "storage-driver": "overlay2",
    "storage-opts": [
        "overlay2.override_kernel_check=true"
]
}
EOF
systemctl daemon-reload && systemctl enable docker && systemctl start docker

cat > /etc/yum.repos.d/k8s.repo << EOF
[kubernetes]
name=Kubernetes
baseurl=https://mirrors.aliyun.com/kubernetes/yum/repos/kubernetes-el7-x86_64/
enabled=1
gpgcheck=0
repo_gpgcheck=0
gpgkey=https://mirrors.aliyun.com/kubernetes/yum/doc/yum-key.gpg https://mirrors.aliyun.com/kubernetes/yum/doc/rpm-package-key.gpg
EOF
yum makecache fast

VER=1.22.4

yum -y install kubeadm-${VER} kubelet-${VER} kubectl-${VER}
systemctl enable kubelet
kubectl completion bash > /etc/bash_completion.d/kubectl    #设置命令补全
kubeadm completion bash > /etc/bash_completion.d/kubeadm  #设置命令补全

kubeadm reset -f 

ipvsadm --clear

rm -rf /etc/cni /etc/kubernetes /var/lib/dockershim /var/lib/etcd /var/lib/kubelet /var/run/kubernetes ~/.kube/*

IP=172.23.15.35

kubeadm init --apiserver-advertise-address=${IP} \
--apiserver-bind-port=6443 \
--pod-network-cidr=10.244.0.0/16 \
--service-cidr=10.96.0.0/12 \
--kubernetes-version=${VER} \
--image-repository registry.aliyuncs.com/google_containers  \
--ignore-preflight-errors=Swap \
--upload-certs \
--v=6

mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config

#export KUBECONFIG=/etc/kubernetes/admin.conf

echo "admin,smd013012,1" > /etc/kubernetes/pki/basic_auth_file

sed -i 's/- --allow-privileged=true/- --feature-gates=RemoveSelfLink=false #添加内容\n    - --allow-privileged=true\n    - --token-auth-file=\/etc\/kubernetes\/pki\/basic_auth_file\n    - --service-node-port-range=1-50000/g' /etc/kubernetes/manifests/kube-apiserver.yaml   

systemctl restart kubelet

sleep 10s

kubectl apply -f flannel.yml
kubectl taint nodes --all node-role.kubernetes.io/master-

kubectl apply -f dashboard.yml

kubectl apply -f dashboard-admin.yml

#kubectl apply -f mandatory.yml

#kubectl apply -f service-nodeport.yaml

mkdir -p /var/jenkins

chmod -R 777 /var/jenkins

kubectl apply -f jenkins.yml

sleep 3s

kubectl create clusterrolebinding test:anonymous --clusterrole=cluster-admin --user=system:anonymous

# 如果忘记kubeadm join增加节点的命令可以使用如下命令重新生成
# kubeadm token create --print-join-command
# kubectl -n kubernetes-dashboard describe secret $(kubectl -n kubernetes-dashboard get secret | grep admin-user | awk '{print $1}')

