#!/bin/bash
kubectl apply -f config.yml
kubectl apply -f etcd-cluster.yml
#kubectl apply -f ingress.yml
kubectl apply -f trace.yml
kubectl apply -f admin.yml
kubectl apply -f micro.yml
