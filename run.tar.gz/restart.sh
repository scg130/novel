#!/bin/bash
#cat > /etc/docker/daemon.json <<eof
#{
#    "exec-opts":["native.cgroupdriver=systemd"],
#    "log-driver":"json-file",
#    "log-opts":{
#        "max-size":"100m"
#    }
#}
#eof


cat > /etc/sysctl.d/k8s.conf << EOF
 net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
net.ipv4.ip_forward=1
vm.swappiness=0
EOF

sysctl --system

cat > /etc/yum.repos.d/kubernetes.repo << EOF 	
[kubernetes]
name = Kubernetes
baseurl = https://mirrors.aliyun.com/kubernetes/yum/repos/kubernetes-el7-x86_64
enabled = 1
gpgcheck = 0
repo_gpgcheck = 0
gpgkey = https://mirrors.aliyun.com/kubernetes/yum/doc/yum-key.gpg https://mirrors.aliyun.com/kubernetes/yum/doc/rpm-package-key.gpg
EOF

mkdir -p /etc/systemd/system.conf.d

cat > /etc/systemd/system.conf.d/kubernetes-accounting.conf << EOF
[Manager]
DefaultCPUAccounting=yes
DefaultMemoryAccounting=yes  
EOF



kubeadm reset -f 

ipvsadm --clear

rm -rf /etc/cni /etc/kubernetes /var/lib/dockershim /var/lib/etcd /var/lib/kubelet /var/run/kubernetes ~/.kube/*

systemctl restart kubelet && systemctl status kubelet

IP=172.23.15.35
#IP=60.205.191.37

kubeadm init --apiserver-advertise-address=${IP} --apiserver-bind-port=6443 --pod-network-cidr=10.244.0.0/16 --service-cidr=10.96.0.0/12 --kubernetes-version=1.22.4 --image-repository registry.aliyuncs.com/google_containers  --ignore-preflight-errors=Swap --upload-certs --v=6

mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config

echo "admin,smd013012,1" > /etc/kubernetes/pki/basic_auth_file

sed -i 's/- --allow-privileged=true/- --feature-gates=RemoveSelfLink=false #添加内容\n    - --allow-privileged=true\n    - --token-auth-file=\/etc\/kubernetes\/pki\/basic_auth_file\n    - --service-node-port-range=1-50000/g' /etc/kubernetes/manifests/kube-apiserver.yaml   

systemctl restart kubelet

sleep 10s

kubectl apply -f flannel.yml
kubectl taint nodes --all node-role.kubernetes.io/master-

kubectl apply -f dashboard.yml

kubectl apply -f dashboard-admin.yml

#kubectl apply -f mandatory.yml

#kubectl apply -f service-nodeport.yaml

chmod -R 777 /var/jenkins

kubectl apply -f jenkins.yml

sleep 3s

kubectl create clusterrolebinding test:anonymous --clusterrole=cluster-admin --user=system:anonymous

# kubectl -n kubernetes-dashboard describe secret $(kubectl -n kubernetes-dashboard get secret | grep admin-user | awk '{print $1}')

#如果忘记kubeadm join增加节点的命令可以使用如下命令重新生成
# kubeadm token create --print-join-command

