#!/bin/bash
docker run -d --name prometheus -p 9191:9090 -v /etc/prometheus/prometheus.yml:/etc/prometheus/prometheus.yml prom/prometheus

docker run -d --name granfana -p 3000:3000 grafana/grafana:6.7.4 grafana
